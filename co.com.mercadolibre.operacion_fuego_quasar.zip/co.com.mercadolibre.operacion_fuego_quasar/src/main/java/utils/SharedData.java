package utils;

public class SharedData {

    private Double sateliteDistance;
    private String satelliteMessage;

    public Double getSateliteDistance() {
        return sateliteDistance;
    }

    public void setSateliteDistance(Double sateliteDistance) {
        this.sateliteDistance = sateliteDistance;
    }

    public String getSatelliteMessage() {
        return satelliteMessage;
    }

    public void setSatelliteMessage(String satelliteMessage) {
        this.satelliteMessage = satelliteMessage;
    }
}
